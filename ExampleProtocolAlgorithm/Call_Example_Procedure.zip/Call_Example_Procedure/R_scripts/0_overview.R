
# This overview script loads the rest of the scripts in the required sequence.
# In this example, we use green toad calls as our target species' sound for
# training.


#####
## Install missing R packages
#
#install.packages('av')
#install.packages('caret')
#install.packages('ggplot2')
#install.packages('parallel')
#install.packages('seewave')
#install.packages('this.path')
#install.packages('tidyverse')
#install.packages('tuneR')
#install.packages('warbleR')
#install.packages('xgboost')

#####
## Check / set folder paths and global constants
#
# Paths to folders and files and global constants are set in 1_global_constants.R
#
# All links in the script are relative and only work if the working directory
# is set to the correct location. If you use RStudio, the R project file should
# do this automatically. Otherwise, the working directory is the folder where
# this script is located.

# Load the global constants (denoted as const_)
source("1_global_constants.R")


#####
## Convert all audio files to WAV
#
# In the example - from MP3 to WAV, but other input audio formats are supported as well

source("2_convert_audio_to_WAV.R")


#####
# Trim the target species audio files, so you obtain files that contain
# just the target sound. 
# The input audio files should be in the wave audio format (*.WAV).
# The output format is also *.WAV. You may end up with multiple output files
# (we denote them with consecutive numbers from a single input file,
# when there are several call sequences present on an input file.

# This executes the script that extracts the target sound.
source("3_target_species_sound_cleaning.R")

#####
# Create the rearranged matrix for all files, for the target species
# and for the non-target (other) sounds. The output matrices are saved as
# RDS files, needed for the next step. Once the MLA has been generated and
# finalized, you may remove the RDSs and clean the .RData to free hard-drive space.


# This executes the script that generates the sound matrices.
# As the file size may be large (>0.5 Gb for both matrices) this process might take up 1-2 min to generate
source("4_create_sound_matrices.R")

#####
# The matrices are used to train a xgboost algorithm. The outputs are:
# 1) The results of an internal comparison
#    (data sets split in training: 70%, testing: 30%);
# 2) The MLA after training again with the entire data set.


#####
# Train and create the MLA.
source("5_MLA_training.R")


## Once you complete the MLA, you can delete the temporary RDS matrices

# Deletes target sounds file if it exists
if (file.exists(const_target_species_training_RDS)) {
  file.remove(const_target_species_training_RDS)
  cat(const_target_species_training_RDS, "deleted.\n")
} else {cat(const_target_species_training_RDS, "not found.\n") }

# Deletes non-target sounds file if it exists
if (file.exists(const_non_target_species_training_RDS)) {
  file.remove(const_non_target_species_training_RDS)
  cat(const_non_target_species_training_RDS, "deleted.\n")
} else {cat(const_non_target_species_training_RDS, "not found.\n") }


#####
# Test the MLA on a sample audio file containing the target sound.
# (a green toad call); this file was not used during the MLA training.
# We use the function target_species_call_detection with the
# above created script. 

# The following code executes the detection function based on the provided audio files.

source("functions_sound_identification.R") # load necessary function 

# List all Wave files in the Sounds_to_identify folder - this allows batch processing of all files in one go 
wav_files<-list.files(path=const_SoundsToIdentify, pattern = ".wav",full.names = T)

# Run the target species detection function.
# If you want to save the ggplots set only_text=F, defaults to T. 
# If you want to save a movie with sound choose save_movie=T, defaults to F. 
results<-target_species_sound_function(wav_files,save_movie=F,only_text=T, xgboostdir=const_MLA_file)



#######################
# Important notes on possible code changes for detecting other sounds or species 
#######################
# The most important changes regard the frequency range that is used in
# trimming the file and producing the spectrogram (set as global constants), 
# as well as the flim values (set as global constants).
# For shorter or longer target sounds the "offset" should be reduced or
# increased, respectively (in the "rearranging_both" function).
