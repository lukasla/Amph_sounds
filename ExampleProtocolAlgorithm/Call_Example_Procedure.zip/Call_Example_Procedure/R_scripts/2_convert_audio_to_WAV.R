
# This script batch processes the audio files and converts them from MP3 to WAV.
# Other input audio formats are supported as well (see av and warbleR documentation).
# However, the output must be WAV for the MLA generation and utilization.

# Load libraries
library(av)
library(warbleR)

# Load the global constants (denoted as const_)
source("1_global_constants.R")
source("functions_sound_identification.R")

# Convert the target species original files
convertMP3_WAV(const_AudioFilesTraining_TargetSource, const_AudioFilesTraining_TargetWAV)
  
# Convert the non-target species original files
convertMP3_WAV(const_AudioFilesTraining_Non_TargetSource, const_AudioFilesTraining_Non_TargetWAV)

