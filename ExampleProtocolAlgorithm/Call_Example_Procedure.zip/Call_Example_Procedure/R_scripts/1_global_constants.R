
# Here we set the locations of folders and files, as well as constants that need
# to be identical between scripts.


### Set default separator for your OS
const_directory_separator<-"/"


# Set folder names for audio for conversions, cleanup, and MLA training
const_AudioFilesTraining_TargetSource <- "../Audio_files_training/target_species_source"
const_AudioFilesTraining_TargetWAV <- "../Audio_files_training/target_species_WAV"
const_AudioFilesTraining_TargetWAV_trimmed <- "../Audio_files_training/target_species_WAV_trimmed"

const_AudioFilesTraining_Non_TargetSource <- "../Audio_files_training/non-target_species_source"
const_AudioFilesTraining_Non_TargetWAV <- "../Audio_files_training/non-target_species_WAV"

# Set sampling rate for WAV files
const_sampling_rate <- 44100

# Set low and high boundaries for the frequencies for first frequency filtering step
const_freq_low <- 1150
const_freq_high <- 1650  

# Set frequency limits for the generated spectrogram -> this is used for creating the numeric matrix that is used for the algorithm
const_flim_low <- 0.8
const_flim_high <- 2

# Offset of 18 is about 0.2 s given the spectrogram defaults and sampling rate.
# The offset defines how long before and after the current time frame should be
# included in the analysis - might depend on the type of sound -
# for green toad calls +/-0.2 s worked well.
const_offset <- 18

# Names of temporary RDSs
##const_target_species_training_RDS<-sprintf("%s", paste(const_base_directory, "Matrix_temporary_RDS_files/target_species_training.rds", sep=const_directory_separator))
const_target_species_training_RDS <- "../Matrix_temporary_RDS_files/target_species_training.rds"

##const_non_target_species_training_RDS<-sprintf("%s", paste(const_base_directory, "Matrix_temporary_RDS_files/non-target_species_training.rds", sep=const_directory_separator))
const_non_target_species_training_RDS <- "../Matrix_temporary_RDS_files/non-target_species_training.rds"

# MLA file
##const_MLA_file<-sprintf("%s", paste(const_base_directory, "MLA/MLA_xgboost_green-toad_example", sep=const_directory_separator))
const_MLA_file <- "../MLA/MLA_xgboost_green-toad_example"

# Directory with files to identify
const_SoundsToIdentify <- "../Sounds_to_identify"

# R RDS file for storing output of the MLA analysis
const_MLA_results_output <- "../MLA_output/results_target_sound.RDS"

