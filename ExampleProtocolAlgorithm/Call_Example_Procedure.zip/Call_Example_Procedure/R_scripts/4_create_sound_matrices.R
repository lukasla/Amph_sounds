
# This script converts the  WAV audio files to the matrices for analysis

# Load libraries
library(seewave)  # To convert files in a matrix 
library(tuneR)    # To import sound files 

# Load the global constants (denoted as const_)
source("1_global_constants.R")

# Load self-written functions
source("functions_sound_identification.R")

# Save target species sound temporary RDS matrix
target_matrix<-create_matrix(const_AudioFilesTraining_TargetWAV_trimmed)

saveRDS(target_matrix, file = const_target_species_training_RDS)

print("***** Target matrix saved")

# Save non-target species sound temporary RDS matrix
non_target_matrix<-create_matrix (const_AudioFilesTraining_Non_TargetWAV)
saveRDS(non_target_matrix, file = const_non_target_species_training_RDS)

print("***** Non-target matrix saved")

