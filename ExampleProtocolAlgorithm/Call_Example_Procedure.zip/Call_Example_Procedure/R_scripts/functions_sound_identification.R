
# The script file for the self-written functions used 


# Batch function to convert all MP3 files in a folder to WAV
convertMP3_WAV<-function(input_folder, output_folder){
  
  # List all MP3 files in the given folder
  mp3_files<-list.files(path=input_folder, pattern = ".mp3")
  
  # Loops through the MP3 file list and convert each to WAV and saves the files in the specified folder
  for (i in 1:length(mp3_files)) {
    destination_wav <- file.path(output_folder, paste0(tools::file_path_sans_ext(basename(mp3_files[i])), ".wav"))
    original_mp3 <- file.path(input_folder, mp3_files[i])
    av_audio_convert(original_mp3, destination_wav)
  }
}

# Function to resample a Wave object to the target sampling rate
resample_wave <- function(wave, const_sampling_rate) {
  if (wave@samp.rate==const_sampling_rate) {return(wave) } else
  {resampled_wave <- resamp(wave, f = wave@samp.rate,g = const_sampling_rate,  output = "Wave")
  return(resampled_wave)}
}


#############################################
# Set up functions for wav file trimming

# Create path to file, based on the const_ target source directory
filename <- function(fname){
  filename_to_trim <- paste0(const_AudioFilesTraining_TargetWAV, const_directory_separator, fname)
}

# Display the spectrogram of the whole original file to trim
display_overall_spectro <-function (filename_to_trim) {
  # Reads the WAV format
  target_sound<-readWave(filename_to_trim)  
  # Extract the sampling rate for the function cutw below
  samp.rate<-target_sound@samp.rate
  # Plotting the spectrogram for the range of interest
  
  seewave::spectro(target_sound,fastdisp=T,flim=c(const_flim_low, const_flim_high),
                   main = tools::file_path_sans_ext(basename(filename_to_trim)) )
}

# Trim the original file to extract the target species into a new file
trim_target_sound <- function(filename_to_trim, trim_from, trim_to,trimmed_files_folder,write_to_file=T) {
  
  target_sound<-readWave(filename_to_trim)   # Reads the WAV format
  
  print(target_sound)
  
  samp.rate<-target_sound@samp.rate # Extract the sampling rate for the function cutw below
  
  target_sound_cut<-cutw(wave = target_sound, from = as.numeric(trim_from), to = as.numeric(trim_to))
  seewave::spectro(target_sound_cut,fastdisp=T,flim=c(const_flim_low, const_flim_high),f=samp.rate,main = paste0(tools::file_path_sans_ext(basename(filename_to_trim)), 
                                                                                                                  " from:", trim_from,"s to:", trim_to,"s"))
  
  if (write_to_file==T) {
    savewav(target_sound_cut, filename = paste0(trimmed_files_folder,"/",
                                                tools::file_path_sans_ext(basename(filename_to_trim)), 
                                                "_", trim_from, "_", trim_to,".wav"), f=samp.rate)}
}


# Rearranging sound files in a matrix for further analysis 
rearranging_both <- function(large_matrix, offset){

  # This is the file that needs to be filled in in the loop below   
  large_matrix_list <- list()
  
  # Transpose the matrix
  large_matrix<-t(large_matrix)
  
  for (i in 1:offset) {
    ncol_data <- ncol(large_matrix)
    nrow_data <- nrow(large_matrix)
    
    spacing<-matrix(NA, nrow = i, ncol = ncol_data)
    
    large_matrix_temp1 <- rbind(spacing,large_matrix)[1:nrow_data,]
    large_matrix_temp2 <- rbind(large_matrix,spacing)[(i+1):(nrow_data+i),]
    
    large_matrix_list[[i]] <- data.frame(large_matrix_temp1)
    large_matrix_list[[i+offset]]<- data.frame(large_matrix_temp2)
  }
  
  large_data_frame<-data.frame(large_matrix,do.call(cbind,large_matrix_list))
  # Scale each row separately
  large_data_frame_scaled<- t(apply(large_data_frame, 1, scale))
  
  large_data_frame_both<-na.omit(data.frame(large_data_frame,large_data_frame_scaled))
  
  return(large_data_frame_both)
}

# Function to create matrix from sound files 
create_matrix <-function (input_directory) {
  
  # Load all the WAV files from the input directory into a list object
  wav_files <- list.files(input_directory, pattern = "\\.wav$", full.names = TRUE)
  wav_list_orig <- lapply(wav_files, readWave)
  
  # Use lapply to resample each Wave object to the set sampling rate
  wav_list <- lapply(wav_list_orig, resample_wave, const_sampling_rate)
  
  # Prepare lists needed in the for-loop underneath
  spectro_list_<-list()
  offset__list<-list()
  test_sounds_list<-list()
  
  # For loop, looping through the WAV files and rearranging them to the format needed for the matrix
  # Briefly:
  # 1) all audios are trimmed to the same frequency range
  # 2) a seewave-spectrogram is generated using default values,
  # providing the the sampling frequency (f), frequency limits (0.8,2),
  # setting fastdisp = T and plot=F
  
  for (i in 1:length(wav_list)) {
    wav_sounds<-wav_list[[i]] # Loop through the list of WAV files 
    samp.rate<-wav_sounds@samp.rate # Extract the sample rate (set in the example at 44100)
    
    wav_sounds_filtered<-seewave::ffilter(wav_sounds, from = const_freq_low, to = const_freq_high) # Filter frequencies, set in the example at  1150-1650
    
    # Make spectrogram
    
    # Create spectrogram without plotting (data are saved)
    spectro_sounds<-seewave::spectro(wav_sounds_filtered, f=samp.rate, flim = c(const_flim_low, const_flim_high),fastdisp=TRUE,plot=F)
    
    # Save spectrogram in list
    spectro_list_[[i]]<-spectro_sounds
    
    # Prepare the matrix for further analysis
    matrix_sounds<-spectro_sounds[["amp"]]
    colnames(matrix_sounds) <- spectro_sounds[["time"]]
    rownames(matrix_sounds) <- spectro_sounds[["freq"]]
    
    offset__list[[i]]<-const_offset
    
    # Using the rearranging function to rearrange the audio data in the same
    # matrix type for all data
    test_sounds_list[[i]]<-rearranging_both(matrix_sounds,offset=const_offset)}#i
  
  test_sounds<-do.call(rbind,test_sounds_list)
  
  # This saves the target species matrix - as the file size may be large (>0.4 Gb) this might take up 1-2 min to generate
  return(test_sounds)
}


# Function for detection of the target sound.
# file_dir is the path to the file directory (if the input is a vector of file directories the algorithm computes the evaluation for each file and the output is a list).
# If save_movie=F (default) then there is no movie of spectrogram (including sound) saved.
# If only_text=T (default) then there is only text output, if "F" there is also a graph produced.
# output_dir is the directory name of the output video, it defaults to the original file name including the extension "_output.mp4".
# xgboostdir is the directory of the xgboost machine learning algorithm to be used.

target_species_sound_function <- function(file_dir,save_movie=F,only_text=T,
                            xgboostdir=const_MLA_file) {
  require(av)
  require(ggplot2)
  require(seewave)
  require(tidyverse)
  require(tuneR)
  require(xgboost)
  
  # Set-up the result list to be filled with the evaluation results
  TSD_list<-list()
  TSD<-vector()
  
  for (i in 1:length(file_dir)) {
  
    plotdir=paste0(tools::file_path_sans_ext(basename(file_dir[i])), "_output.pdf")
    output_dir=paste0(tools::file_path_sans_ext(basename(file_dir[i])), "_output.mp4")
    
  # Load the MLA; must be in the working directory 
  xgbst<-xgb.load(xgboostdir)
  
  # Read in wave file 
  wave_file<-readWave(file_dir[i])
  
  # Extract sampling frequency 
  samp.rate1<-wave_file@samp.rate
  
  #######################
  # Resample, filter and then rearrange the file in the same way as the training data set 
  
  wave_file<-resample_wave(wave_file,const_sampling_rate)
  
  samp.rate<-wave_file@samp.rate
  
  wave_file_filtered<-seewave::ffilter(wave_file, from = const_freq_low, to = const_freq_high) # Filter frequencies, set in the example at  1150-1650

  # Make quick spectrogram, without plotting it
  spectro_<-seewave::spectro(wave_file_filtered, f = samp.rate, flim = c(const_flim_low, const_flim_high),fastdisp = T,plot=F)
 
  
  matrix_MLA_result<-spectro_[["amp"]]
  colnames(matrix_MLA_result) <- spectro_[["time"]]
  rownames(matrix_MLA_result) <- spectro_[["freq"]]
  
  wave_file_rearranged<-rearranging_both(matrix_MLA_result,offset=const_offset)
  
  # Run the predictions
  
  # Remove NAs
  wave_file_rearranged<-na.omit(wave_file_rearranged)
  
  if (nrow(wave_file_rearranged)==0) {TSD[i]<-sprintf("%s", paste(file_dir[i], "No sound detected", sep="|")); print(TSD[i]);TSD_list[[i]]<-TSD[i]} else {
  
  x<-as.numeric(rownames(wave_file_rearranged)) #saving the rownumbers -> needed for plotting 
  
  wave_file_rearranged <- xgb.DMatrix(data = as.matrix(wave_file_rearranged), label = rep(1,nrow(wave_file_rearranged))) 
  
  pwave_file <- predict(xgbst, wave_file_rearranged) 
  
  pwave_file <-factor(ifelse(as.numeric(pwave_file > 0.5)==1,"target sp sound","other"),levels=c("target sp sound","other")) 
  
  pwave_file_df <- as.data.frame(pwave_file)
  
  # Assign a unique color to each level
  colors <- c( "green4","darkgrey")  # Change or expand colors as needed
  
  # Map factor levels to colors
  y_colors <- colors[as.numeric(pwave_file_df$pwave_file)]
  
  y<-relevel(pwave_file_df$pwave_file,ref="other")
  
  timesr<-ifelse(max(x)<60*2,"Time (s)","Time (min)")
  fact<-ifelse(max(x)<60*2,1,1/60)
  
  df_<-data.frame(x*fact,y)
  other=0.9;greent=1.7
  df_$y<-ifelse(df_$y=="other",other,greent)
  df_$y_colors<-ifelse(df_$y==other,NA,"green4") # Removes the "other" 
  
  # Add the length for animations 
  by__<-mean((df_ %>%mutate(Diff = x...fact - lag(x...fact)))$Diff,na.rm = T)  # Average of times between values 
  length_<-seq(0,max(df_$x...fact),by=by__) # Creates time axis 
  
  # Remove the "others" 
  df_<-na.omit(df_)
  
  suppressWarnings(
  suppressMessages(
  p <-ggspectro(wave_file_filtered, f=samp.rate , ovlp=50) + ylim(0.8,1.8)+
    stat_contour(geom="polygon", aes(fill=..level..), bins=30)+
    scale_fill_gradientn(name="Amplitude\n(dB)\n", limits=c(-60,0),
                         na.value="transparent", colours = spectro.colors(60))+
    theme_minimal()+ theme(legend.position="none")+
    geom_point(data = df_, alpha = 5/10,
               color=df_$y_colors, shape=18,size=5,
               mapping = aes(x = x...fact, y = y+0.04, z=rep(1,nrow(df_))))))
  if (only_text==F) {suppressMessages(suppressWarnings(ggsave(plotdir,p)))}
  
  if (save_movie == T) {
    
    ##### Function to make a video 
    make_video <- function(){
      for (i in length_) {
        
        df_2<-df_[df_$x...fact<=i,] # Select the points at times smaller than the vline
        df_3<- data.frame(i,max(length_),-Inf,Inf);colnames(df_3)<-colnames(df_3) <- c("xmin", "xmax", "ymin", "ymax")
        
        
        suppressWarnings(
          suppressMessages(
        p <-ggspectro(wave_file_filtered, f=samp.rate , ovlp=50) + ylim(0.8,1.8)+
          stat_contour(geom="polygon", aes(fill=..level..), bins=30)+
          scale_fill_gradientn(name="Amplitude\n(dB)\n", limits=c(-60,0),
                               na.value="transparent", colours = spectro.colors(60))+
          theme_minimal()+ theme(legend.position="none")+
          geom_point(data = df_2, alpha = 5/10,
                     color=df_2$y_colors, shape=18,size=5,
                     mapping = aes(x = x...fact, y = y+0.04, z=rep(1,nrow(df_2))))+
          ggplot2::geom_rect(data = df_3,inherit.aes = F,color = NA,
                             aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,color = 'grey', alpha=0.2)) ))
        suppressWarnings(suppressMessages(print(p)))
        
      }}
    
    # Make the movie 
    framrate_<-(length(length_))/max(length_)
    
    av_capture_graphics(
      make_video(),
      output = output_dir,
      width = 720,
      height = 480,
      framerate = framrate_,
      audio = file_dir) # 
  } # End of movie production
  
  rle_result <- rle(as.character(pwave_file_df$pwave_file)) #Compute the lengths and values of runs of equal values in a vector 
  
  occ_counts <- data.frame(
    factor_level = rle_result$values,
    count = rle_result$lengths)
  
  occ_counts_targetsp_frames <- occ_counts[occ_counts$factor_level=="target sp sound",]
  max_count<-sort(occ_counts_targetsp_frames$count, decreasing=T,na.last = TRUE)[1]
  if (is.na(max_count)){max_count<-0 }
  
  if (max_count==length(pwave_file_df$pwave_file)) {TSD[i]<- sprintf("%s", paste(file_dir[i], "All time points identified as target species, check potential false positives!", sep="|"))} else{
  if (max_count<2) {TSD[i]<- sprintf("%s", paste(file_dir[i], "Target species not detected", sep="|"))} else {
    
    # If more than 10 consecutive occurrences -> then we consider this a positive match
    TSD[i]<-ifelse(max(occ_counts_targetsp_frames$count)>=10,
                sprintf("%s", paste(file_dir[i], "Target species detected", sep="|")),
                sprintf("%s", paste(file_dir[i], "Non-definitive result; double check", sep="|")))}}
    
    time_points_TS<-df_$x...fact
    TSD_list[[i]]<-list(TSD[i],time_points_TS,xgboostdir) # If sound detected 
  print(paste("File", i,"of", length(file_dir), TSD[i], sep=" "))}}

  if(only_text==T) {return(TSD) } else {return(TSD_list)}
  
}
