
# This script is used to import the target species WAV audio files and cut out
# only the target sound sequences. 
# It is important that this is done correctly, otherwise the MLA will be
# trained on wrong sounds.

# If you receive an error message: "Error in plot.new() : figure margins too large",
# increase the size of the Plots Panel in RStudio.

# Load libraries
library(av)       # for audio conversions
library(seewave)  # to cut the files
library(tuneR)    # to import sound files

# Load the global constants (denoted as const_)
source("1_global_constants.R")
source("functions_sound_identification.R")

##############################
# Below we go file by file and trim/extract the useful sounds from the
# target species audio files
#############################

##############################
##### File 1: "949815.wav"
#############################

clean_target_sound_filename<-filename("949815.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 18, trim_to = 19.1,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                   trim_from = 25, trim_to = 28,
                   const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 38, trim_to = 40,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 54, trim_to = 56,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 77, trim_to = 80,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 2: "949981.wav"
##############################

clean_target_sound_filename<-filename("949981.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 24.5, trim_to = 28,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 3: "950401.wav"
#############################
# This file contains a lot of noise - therefore working with the spectrograms does not work
# I listened to the WAV file and identified a few parts with calling toads:
# First is from 9s to 12s 
# then 17-20s
# then 29-31s
# then 1:11-1:13 (71-73s)
# then 1:16-1:20 (76-80s)

clean_target_sound_filename<-filename("950401.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 76, trim_to = 80,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 4: "951321.wav"
#############################

clean_target_sound_filename<-filename("951321.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 6.5, trim_to = 9.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 5: "952064.wav"
#############################

# There are several calls here; I took the first 5 for this example 

clean_target_sound_filename<-filename("952064.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0, trim_to = 2.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 11, trim_to = 17,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 24, trim_to = 28,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 52, trim_to = 60,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 69, trim_to = 80,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 6: "952215.wav"
#############################

# There are 4 separate call sequences in here.

clean_target_sound_filename<-filename("952215.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.2, trim_to = 1.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 3.5, trim_to = 7,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 10, trim_to = 12.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 15.4, trim_to = 18,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 7: "952733.wav"
#############################

clean_target_sound_filename<-filename("952733.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 9.6, trim_to = 11,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 8: "952746.wav"
#############################

# There are several calls here; I took the first 5 for this example 

clean_target_sound_filename<-filename("952746.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 11, trim_to = 13,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 9: "952749.wav"
#############################

# There are several calls here; I took the first 5 for this example 

clean_target_sound_filename<-filename("952749.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

# Below the files are trimmed according to target sound occurrence.
# The trimmed spectrograms should and can be inspected before saving by setting the parameter "write_to_file=F".

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 12, trim_to = 14.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 10: "952759.wav"
#############################

clean_target_sound_filename<-filename("952759.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 3.5, trim_to = 4,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 8, trim_to = 10,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 14.5, trim_to = 16,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 11: "953458.wav"
#############################

clean_target_sound_filename<-filename("953458.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0, trim_to = 2,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 6, trim_to = 12,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 20, trim_to = 25,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 27.5, trim_to = 35,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 37.5, trim_to = 41.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 12: "954100.wav"
#############################

clean_target_sound_filename<-filename("954100.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.15, trim_to = 2.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 13: "954102.wav"
#############################

clean_target_sound_filename<-filename("954102.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.2, trim_to = 3,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 14: "961035.wav"
#############################

clean_target_sound_filename<-filename("961035.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.4, trim_to = 3,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 11, trim_to = 16,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 19, trim_to = 21,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 28, trim_to = 34,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 14: "961831.wav"
#############################

clean_target_sound_filename<-filename("961831.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.4, trim_to = 5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 15: "9618431.wav"
#############################

clean_target_sound_filename<-filename("961843.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.4, trim_to = 4,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 12, trim_to = 19,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 16: "965094.wav"
#############################

clean_target_sound_filename<-filename("965094.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0.2, trim_to = 2,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 17: "965118.wav"
#############################

clean_target_sound_filename<-filename("965118.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 1, trim_to = 3.8,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 18: "965737.wav"
#############################

clean_target_sound_filename<-filename("965737.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 5.2, trim_to = 12,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 19: "965741.wav"
#############################

clean_target_sound_filename<-filename("965741.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 2.3, trim_to = 3.6,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 5, trim_to = 10,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 20: "965767.wav"
#############################

clean_target_sound_filename<-filename("965767.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 10, trim_to = 12,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 21: "966263.wav"
#############################

clean_target_sound_filename<-filename("966263.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 6, trim_to = 10,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 22: "969403.wav"
#############################

clean_target_sound_filename<-filename("969403.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0, trim_to = 3,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 11, trim_to = 19,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 36, trim_to = 38.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 23: "969450.wav"
#############################

clean_target_sound_filename<-filename("969450.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 0, trim_to = 2.8,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 24: "973696.wav"
#############################

clean_target_sound_filename<-filename("973696.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 5.3, trim_to = 7.6,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 25: "975199.wav"
#############################

# There are several call sequences in here, we took 5. 

clean_target_sound_filename<-filename("975199.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 10.5, trim_to = 12,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 26, trim_to = 28,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 35, trim_to = 37,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 26: "976264.wav"
#############################

# There are several call sequences in here, we took 5. 

clean_target_sound_filename<-filename("976264.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 


trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 2.8, trim_to = 4.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)


##############################
##### File 27: "977366.wav"
#############################

clean_target_sound_filename<-filename("977366.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 6.5, trim_to =7.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 23.8, trim_to = 25.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

##############################
##### File 28: "977494.wav"
#############################

clean_target_sound_filename<-filename("977494.wav") # Load the file using the custom function

display_overall_spectro(clean_target_sound_filename) # Show the spectrogram for the whole audio file 

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 10, trim_to = 12.5,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

trim_target_sound(filename_to_trim = clean_target_sound_filename, 
                  trim_from = 20, trim_to = 22,
                  const_AudioFilesTraining_TargetWAV_trimmed,write_to_file=T)

