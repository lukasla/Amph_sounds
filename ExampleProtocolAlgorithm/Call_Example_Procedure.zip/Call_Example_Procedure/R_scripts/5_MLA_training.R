
# Training the xgboost algorithm (MLA)

# Load libraries 
library(caret)    # To generate confusion matrix
library(parallel) # For parallel processing
library(xgboost)  # For xgboost algorithm

# Load the global constants (denoted as const_)
source("1_global_constants.R")

# Load the RDS files 
training_targetsp<-readRDS(const_target_species_training_RDS)
training_non_targetsp<-readRDS(const_non_target_species_training_RDS)

# Rearrange the files and add "target sp sound" versus "other"
Sound_class<-c(rep("target sp sound",nrow(training_targetsp)),
               rep("other",nrow(training_non_targetsp)))
training_set<-data.frame(as.factor(Sound_class),rbind(training_targetsp,training_non_targetsp))

# The type of call is named sound_class (i.e., target species sound and other)
colnames(training_set)[1]<-"Sound_class"

# Removes files that are not needed any more to free up memory
rm(training_non_targetsp)
rm(training_targetsp) 

# Remove possible NAs
training_set<-na.omit(training_set) 

# Train the xgboost algorithm with 70% of the data 

set.seed(0) # Sets seed for reproducible results 

ind <- sample(2, nrow(training_set), replace = TRUE, prob = c(0.7, 0.3)) # Index to split in 70% and 30%
train <- training_set[ind==1,];train_pred<-train[,-1] # Get 70% training data set 
test <- training_set[ind==2,];test_pred<-test[,-1] # Get 30% testing data set 

cores_<-parallel::detectCores() # Set number of cores 

num_soundclass<-(as.numeric(train$Sound_class))-1 # Change the sound class in numbers (needed for xgboost)

# Change training data set in the matrix type needed for xgboost
dtrain <- xgb.DMatrix(data = as.matrix(train_pred), label = num_soundclass)

# Train the first xgboost algorithm with 70% of the data
xgbst_1stround<- xgboost(data = dtrain, max.depth = 100, eta = 1, 
                         nthread = cores_, nrounds = 100, verbose = 1,
                         objective = "binary:logistic")

# Test the performance of the 70% trained MLA 
num_soundclass_test<-(as.numeric(test$Sound_class))-1 # Change sound class in numbers (for testing)

# "label" is just a dummy here
dtest <- xgb.DMatrix(data = as.matrix(test_pred), label = rep(1,length(num_soundclass_test)))  

pred <- predict(xgbst_1stround, dtest) # Predictions on split test data set
p5_pred <- as.factor(as.numeric(pred > 0.5)) # Everything above 0.5 is set to 1, below to 0

# The prediction is compared to the actual soundclass - confusion matrix is calculated
confusion_m<-confusionMatrix(p5_pred, as.factor(num_soundclass_test))

confusion_m # Show the confusion matrix

# Saves the results of the confusion matrix, which shows the accuracy of the MLA when tested within the training and testing data-sets
sink("../MLA/MLA_confusion_matrix.txt")
cat("Results for the MLA ", const_MLA_file, "\n", date(), "\n\n", sep="")
print(confusion_m)
sink()      
print(paste("***** Saved confusion matrix as ", "../MLA/MLA_confusion_matrix.txt"))

####################################
# Compose the final MLA by training on 100% of the provided data 
###################################

total_data <-training_set[,-1] # Take entire data set  
num_soundclass<-(as.numeric(training_set$Sound_class))-1 # Transform to numbers 

# Train the final MLA
dtotal <- xgb.DMatrix(data = as.matrix(total_data), label = num_soundclass)
xgbst_Final <- xgboost(data = dtotal, max.depth = 100, eta = 1, 
                      nthread = cores_, nrounds = 100, verbose = 1,
                      objective = "binary:logistic")

# Save the MLA as a xgboost file
xgb.save(xgbst_Final, const_MLA_file)

print(paste("***** MLA saved as", const_MLA_file))

# Load the MLA 
xgbst<-xgb.load(const_MLA_file)

